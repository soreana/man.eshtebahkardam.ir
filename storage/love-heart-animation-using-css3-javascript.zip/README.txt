A Pen created at CodePen.io. You can find this one at https://codepen.io/vivinantony/pen/gbENBB.

 http://blog.thelittletechie.com/2015/03/love-heart-animation-using-css3.html